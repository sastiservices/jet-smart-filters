<?php
/**
 * Active tag value template
 */

?>
<div class="jet-active-tag__val">/% $value %/</div>